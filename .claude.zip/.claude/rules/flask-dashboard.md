---
name: flask-dashboard-rules
description: Conventions for the Flask diagnostic dashboard. Loads when editing web/.
applyTo:
  - "web/**/*.py"
  - "web/templates/**/*"
---

# Flask Dashboard Rules

## This is the diagnostic dashboard, not the user-facing UI
- The user-facing UI is the Vue 3 app at `../Violence_Prevention_Frontend`.
- This Flask app (`web/app.py`) is for ML diagnostics, calibration, and developer-facing inspection. Don't try to make it pretty.
- If a request says "the dashboard", clarify which one before assuming.

## Routes
- Keep route handlers thin. Inference logic stays in the detection modules; the route just calls them and renders.
- Always declare `methods=['GET']` / `methods=['POST']` explicitly — don't rely on Flask's defaults.
- Return JSON for anything that the Vue frontend might consume; render templates only for the human-facing diagnostic pages.

## Auth (`web/auth.py`)
- Don't bypass auth for "convenience" routes. If a diagnostic route is sensitive, gate it the same way.
- No hardcoded credentials. Read from env.

## Templates (`web/templates/`)
- Plain Jinja2. No JS frameworks here.
- Server-rendered forms — diagnostic UI should work without JS where possible.

## Don't import detection scripts at module top-level if they're heavy
Loading a Keras model on import means every Flask reload pays for it. Defer model loads to first-use or a startup hook.

## Anti-patterns
- ❌ Stuffing inference code into the route handler
- ❌ Calling subprocess to invoke a `.bat` from a Flask route (use the Python module directly)
- ❌ Returning HTML from a route the Vue frontend is supposed to call
