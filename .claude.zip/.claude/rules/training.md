---
name: training-script-rules
description: Conventions for training pipelines. Loads when editing train_*.py or anything under models/.
applyTo:
  - "train_*.py"
  - "models/**/*"
  - "*_data_generation.py"
---

# Training Pipeline Rules

## Reproducibility is non-negotiable
- Every training script must set seeds: `numpy`, `random`, `tensorflow`, `os.environ['PYTHONHASHSEED']`.
- If you change a seed, document why in the commit message.
- Log the seed at the start of every run.

## Plans for training-related changes must specify
1. Dataset path (absolute or via settings)
2. Random seed used
3. Output checkpoint path (where will the `.h5` land?)
4. Eval procedure (which test split, which metric)
5. Expected runtime ballpark — if the user might wait hours, say so before kicking off

## Verifying a training-code change ≠ running full training
Run **1–2 epochs on a tiny subset** to confirm the loop completes, the loss goes down at all, and checkpoints save correctly. Do NOT propose "let's run full training to verify" — that's a waste of GPU hours.

## Model artifacts (`models/`)
- `.h5` files are large. Do NOT `git add` a new one without explicit user approval.
- When introducing a new model file, update `config/settings.py` to point to it AND add a note to the relevant doc (`BLUEPRINT.md` or `IMPLEMENTATION_SUMMARY.md`) describing what changed and why.
- The legacy `.h5.bak` files exist for a reason; don't auto-delete them.

## Dataset signal files (`*.txt` at repo root)
`violent.txt`, `neutral.txt`, `carrying.txt`, `grasping.txt`, `gripping.txt`, `holding.txt`, `cupping.txt`, `resting.txt` — these list training samples per class. When adding a class:
- Add the `.txt` file
- Wire it into the training script's class list
- Update the model output layer dimension to match
- Update any inference script's label mapping
- Update docs that enumerate classes

Missing any of these = silent breakage at inference time.

## Don't silently change architecture
LSTM vs Hybrid CNN-GRU vs TCN — these are documented choices in `BLUEPRINT.md` / `PROJECT_ANALYSIS.md`. Architectural swaps need a plan + sign-off, not a drive-by commit.
