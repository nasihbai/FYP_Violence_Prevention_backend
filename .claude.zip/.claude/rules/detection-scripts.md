---
name: detection-script-rules
description: Conventions for inference / detection Python scripts. Loads when editing detect_*.py, run_*.py, or hands/pose realtime scripts.
applyTo:
  - "detect_*.py"
  - "run_*.py"
  - "hands_*.py"
  - "pose_*.py"
  - "web_dashboard_*.py"
---

# Detection / Inference Script Rules

## Calibrated code — handle with care
The files matching `hands_lstm_realtime*.py`, `pose_lstm_realtime.py`, and `detect_violence.py` are **tied to trained model weights in `models/`**. Cosmetic changes are fine; any change to:
- Input preprocessing (frame size, color space, normalization)
- Sequence length / sliding window
- Feature extraction order
- Output thresholding

...will silently shift predictions. **Get explicit sign-off before changing these.**

## All tunables live in `config/settings.py`
If you find a magic number in a detection script, refactor it into `settings.py` as part of your change. Examples that must NOT be inline:
- Confidence thresholds
- Frame counts / sequence length
- Webcam device index (never hardcode `0`)
- Model file paths (read from settings, not literal strings)
- IOU / NMS thresholds for YOLO

## OpenCV resource hygiene
Every `cv2.VideoCapture(...)` needs a matching `.release()`. Every `cv2.namedWindow(...)` or implicit `cv2.imshow(...)` needs `cv2.destroyAllWindows()` on exit. Wrap loops in `try/finally` to guarantee cleanup even on KeyboardInterrupt.

## Entry points
- Don't propose a new way to launch a script without updating (or adding) the matching `.bat` runner.
- Canonical runners: `run_detection.bat`, `run_optimized_dashboard.bat`, `run_web_dashboard.bat`, `run_webcam.bat`.

## TF / GPU
- `os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'` to suppress info logs is fine; suppressing WARNINGS hides real bugs.
- If users report "the model is broken" — your first response is to restart the Python process and re-run. Stale CUDA state is the #1 false alarm.
- Don't `tf.config.experimental.set_memory_growth` inside a runtime script without checking — it changes behavior for every other detector that imports the module.

## Logging
- Use `logging`, not `print`, for any new code that needs to persist.
- INFO for normal flow, WARNING for recoverable issues, ERROR for failures the user should see.
- Don't log inside the per-frame inference loop (drowns the log).
